# Gemini Telegram OCR Bot (Render Polling Version)

This version is built to run on Render the same way long-running Telegram bots usually work:

- `python app.py`
- Telegram **polling** mode
- small built-in **health server** for Render
- no webhook setup needed

## Why this version

Your previous webhook version could run, but if the webhook was not connected to the correct bot token or webhook URL, Telegram messages would never reach the app.

This version avoids that whole problem by using polling, similar to your Probaho bot pattern.

## Commands

- `/start`
- `/help`
- `/commands`
- `/ping`
- `/id`

## What it does

- Send a **photo** -> OCR
- Send an **image document** -> OCR
- Send a **PDF** -> OCR
- Add a caption for extra instruction

## Render deploy

### Build Command

```bash
pip install -r requirements.txt
```

### Start Command

```bash
python app.py
```

### Health Check Path

```text
/healthz
```

## Environment variables

```env
TELEGRAM_BOT_TOKEN=your_telegram_bot_token
GEMINI_API_KEY=your_gemini_api_key
GEMINI_MODEL=gemini-2.5-flash
MAX_FILE_SIZE_MB=15
LOG_LEVEL=INFO
```

## Notes

- This version does **not** need webhook setup.
- After deploy, just open the bot in Telegram and send `/start`.
- Root URL `/` and `/healthz` both return JSON so Render health checks pass.
