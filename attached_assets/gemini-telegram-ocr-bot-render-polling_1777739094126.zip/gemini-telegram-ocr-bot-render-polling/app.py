import asyncio
import json
import logging
import mimetypes
import os
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import List, Optional, Tuple

from dotenv import load_dotenv
from google import genai
from google.genai import types
from telegram import BotCommand, Update
from telegram.constants import ChatAction
from telegram.ext import (
    Application,
    ApplicationBuilder,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

load_dotenv()

LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()
logging.basicConfig(
    level=getattr(logging, LOG_LEVEL, logging.INFO),
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger("gemini-telegram-ocr-bot")

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip()
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash").strip()
MAX_FILE_SIZE_MB = int(os.getenv("MAX_FILE_SIZE_MB", "15"))
PORT = int(os.getenv("PORT", "10000"))

OCR_PROMPT = """You are a precise OCR engine.
Extract all visible text from the provided file.
Rules:
1. Preserve line breaks as much as possible.
2. Do not summarize.
3. Do not translate.
4. If there is a table, output it in readable plain text.
5. If any portion is unclear, make your best effort and mark uncertain parts with [?].
6. If there is no readable text, reply exactly with: NO_READABLE_TEXT
"""

HELP_TEXT = (
    "আমাকে ছবি বা PDF পাঠান, আমি OCR করে text বের করে দেব।\n\n"
    "কাজের নিয়ম:\n"
    "- photo পাঠালে text extract করব\n"
    "- image file / PDF document পাঠালেও কাজ করবে\n"
    "- চাইলে caption-এ extra instruction দিতে পারেন\n\n"
    "কমান্ডসমূহ:\n"
    "/start - bot শুরু\n"
    "/help - usage guide\n"
    "/commands - command list\n"
    "/ping - bot live কিনা\n"
    "/id - chat id দেখাবে\n\n"
    "উদাহরণ:\n"
    "1) শুধু ছবি পাঠান\n"
    "2) PDF পাঠিয়ে caption দিন: only extract invoice total"
)

BOT_COMMANDS = [
    BotCommand("start", "Start the OCR bot"),
    BotCommand("help", "Show usage guide"),
    BotCommand("commands", "Show all commands"),
    BotCommand("ping", "Check bot status"),
    BotCommand("id", "Show chat id"),
]


def chunk_text(text: str, max_length: int = 4000) -> List[str]:
    text = text or ""
    if len(text) <= max_length:
        return [text]

    chunks: List[str] = []
    current = ""
    for line in text.splitlines(True):
        if len(current) + len(line) > max_length:
            if current:
                chunks.append(current)
                current = ""
        if len(line) > max_length:
            start = 0
            while start < len(line):
                chunks.append(line[start : start + max_length])
                start += max_length
        else:
            current += line
    if current:
        chunks.append(current)
    return chunks


def build_ocr_prompt(extra_instruction: str = "") -> str:
    extra_instruction = (extra_instruction or "").strip()
    if not extra_instruction:
        return OCR_PROMPT
    return f"{OCR_PROMPT}\nAdditional user instruction: {extra_instruction}"


def run_gemini_ocr(file_bytes: bytes, mime_type: str, extra_instruction: str = "") -> str:
    if not GEMINI_API_KEY:
        raise RuntimeError("GEMINI_API_KEY is missing")

    client = genai.Client(api_key=GEMINI_API_KEY)
    part = types.Part.from_bytes(data=file_bytes, mime_type=mime_type)
    response = client.models.generate_content(
        model=GEMINI_MODEL,
        contents=[part, build_ocr_prompt(extra_instruction)],
    )
    text = (response.text or "").strip()
    if text == "NO_READABLE_TEXT":
        return "কোনো readable text পাওয়া যায়নি।"
    return text or "কোনো text পাওয়া যায়নি।"


async def send_text_chunks(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
    text: str,
) -> None:
    if not update.effective_message:
        return

    safe_text = (text or "").strip() or "কোনো text detect হয়নি।"
    for chunk in chunk_text(safe_text):
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text=chunk,
            reply_to_message_id=update.effective_message.message_id,
        )


async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await send_text_chunks(update, context, HELP_TEXT)


async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await send_text_chunks(update, context, HELP_TEXT)


async def cmd_commands(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    text = (
        "Available commands:\n"
        "/start - Start the OCR bot\n"
        "/help - Show usage guide\n"
        "/commands - Show all commands\n"
        "/ping - Check bot status\n"
        "/id - Show chat id"
    )
    await send_text_chunks(update, context, text)


async def cmd_ping(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await send_text_chunks(update, context, f"pong\nmodel: {GEMINI_MODEL}")


async def cmd_id(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    chat_id = update.effective_chat.id if update.effective_chat else "unknown"
    user_id = update.effective_user.id if update.effective_user else "unknown"
    await send_text_chunks(update, context, f"chat_id: {chat_id}\nuser_id: {user_id}")


async def handle_plain_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not update.effective_message or not update.effective_message.text:
        return
    await send_text_chunks(update, context, "ছবি বা PDF পাঠান। /help দিলে usage দেখাবো।")


def detect_supported_message(update: Update) -> Tuple[str, str, str]:
    if not update.effective_message:
        raise ValueError("No message found")

    message = update.effective_message

    if message.photo:
        best_photo = max(message.photo, key=lambda x: x.file_size or 0)
        return best_photo.file_id, "image/jpeg", "photo.jpg"

    document = message.document
    if not document:
        raise ValueError("No supported media found")

    mime_type = document.mime_type or mimetypes.guess_type(document.file_name or "document")[0] or "application/octet-stream"
    allowed_exact = {"application/pdf"}
    if not (mime_type.startswith("image/") or mime_type in allowed_exact):
        raise ValueError("Only images and PDF documents are supported")

    return document.file_id, mime_type, document.file_name or "document"


async def download_telegram_file(application: Application, file_id: str) -> bytes:
    telegram_file = await application.bot.get_file(file_id)
    data = await telegram_file.download_as_bytearray()
    return bytes(data)


async def handle_media(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not update.effective_message or not update.effective_chat:
        return

    try:
        file_id, mime_type, file_name = detect_supported_message(update)
        file_bytes = await download_telegram_file(context.application, file_id)

        file_size_mb = len(file_bytes) / (1024 * 1024)
        if file_size_mb > MAX_FILE_SIZE_MB:
            await send_text_chunks(
                update,
                context,
                f"ফাইলটি অনেক বড় ({file_size_mb:.2f} MB)। MAX_FILE_SIZE_MB এখন {MAX_FILE_SIZE_MB} MB সেট করা আছে।",
            )
            return

        logger.info("Processing file %s (%s)", file_name, mime_type)
        await context.bot.send_chat_action(chat_id=update.effective_chat.id, action=ChatAction.TYPING)

        extra_instruction = update.effective_message.caption or ""
        ocr_text = await asyncio.to_thread(run_gemini_ocr, file_bytes, mime_type, extra_instruction)
        await send_text_chunks(update, context, ocr_text)

    except ValueError as exc:
        await send_text_chunks(update, context, str(exc))
    except Exception as exc:
        logger.exception("OCR processing failed")
        await send_text_chunks(update, context, f"প্রসেস করতে সমস্যা হয়েছে: {exc}")


async def post_init(application: Application) -> None:
    try:
        await application.bot.set_my_commands(BOT_COMMANDS)
        logger.info("Bot commands registered")
    except Exception:
        logger.exception("Failed to register bot commands")


def _health_payload() -> bytes:
    payload = {
        "ok": True,
        "service": "gemini-telegram-ocr-bot",
        "mode": "polling",
        "model": GEMINI_MODEL,
    }
    return json.dumps(payload, ensure_ascii=False).encode("utf-8")


def run_render_health_server() -> None:
    class HealthHandler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:
            if self.path not in ("/", "/healthz"):
                self.send_response(404)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.end_headers()
                self.wfile.write(b'{"ok": false, "error": "not_found"}')
                return

            body = _health_payload()
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, fmt: str, *args) -> None:
            return

    server = HTTPServer(("0.0.0.0", PORT), HealthHandler)
    logger.info("Health server started on port %s", PORT)
    server.serve_forever()


def build_app() -> Application:
    if not TELEGRAM_BOT_TOKEN:
        raise RuntimeError("TELEGRAM_BOT_TOKEN is missing")

    application = ApplicationBuilder().token(TELEGRAM_BOT_TOKEN).post_init(post_init).build()

    application.add_handler(CommandHandler("start", cmd_start))
    application.add_handler(CommandHandler("help", cmd_help))
    application.add_handler(CommandHandler("commands", cmd_commands))
    application.add_handler(CommandHandler("ping", cmd_ping))
    application.add_handler(CommandHandler("id", cmd_id))
    application.add_handler(MessageHandler(filters.PHOTO | filters.Document.ALL, handle_media))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_plain_text))

    return application


def main() -> None:
    if not TELEGRAM_BOT_TOKEN:
        raise SystemExit("TELEGRAM_BOT_TOKEN is missing")
    if not GEMINI_API_KEY:
        raise SystemExit("GEMINI_API_KEY is missing")

    threading.Thread(target=run_render_health_server, daemon=True).start()
    app = build_app()

    logger.info("Starting Gemini Telegram OCR Bot in polling mode")
    logger.info("Model: %s", GEMINI_MODEL)
    app.run_polling(drop_pending_updates=True, allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
